"""Enterprise Knowledge & Research Agent - Flask entry point (Step 1: scaffold only)."""
from pathlib import Path

from flask import Flask, jsonify, render_template, request
from werkzeug.utils import secure_filename

from config import Config

app = Flask(__name__)
app.config.from_object(Config)

# Make sure the working folders exist.
Config.UPLOAD_FOLDER.mkdir(exist_ok=True)
Config.DATA_FOLDER.mkdir(exist_ok=True)


def allowed_file(filename: str) -> bool:
    """Accept only whitelisted extensions (PDF for now)."""
    return "." in filename and filename.rsplit(".", 1)[1].lower() in Config.ALLOWED_EXTENSIONS


@app.route("/")
def index():
    """Render the main page."""
    return render_template("index.html")


@app.route("/health")
def health():
    """Simple health check, handy for testing that the server is up."""
    return jsonify(status="ok", groq_configured=bool(Config.GROQ_API_KEY))


@app.route("/upload", methods=["POST"])
def upload():
    """Save an uploaded PDF to /uploads. Text extraction and indexing come in a later step."""
    file = request.files.get("file")
    if file is None or file.filename == "":
        return jsonify(error="No file selected."), 400
    if not allowed_file(file.filename):
        return jsonify(error="Only PDF files are supported."), 400

    filename = secure_filename(file.filename)
    file.save(Config.UPLOAD_FOLDER / filename)
    return jsonify(message=f"'{filename}' uploaded.", filename=filename)


@app.route("/documents")
def documents():
    """List the files currently in /uploads."""
    files = sorted(p.name for p in Path(Config.UPLOAD_FOLDER).glob("*.pdf"))
    return jsonify(documents=files)


@app.route("/ask", methods=["POST"])
def ask():
    """Placeholder chat endpoint. Will call the agent (RAG + Groq + tools) in later steps."""
    question = (request.get_json(silent=True) or {}).get("question", "").strip()
    if not question:
        return jsonify(error="Please enter a question."), 400
    return jsonify(
        answer="The AI agent is not connected yet. This is a placeholder response.",
        sources=[],
    )


@app.errorhandler(413)
def too_large(_):
    """Return a friendly message when an upload exceeds MAX_CONTENT_LENGTH."""
    return jsonify(error="File is too large."), 413


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=Config.PORT, debug=Config.DEBUG)

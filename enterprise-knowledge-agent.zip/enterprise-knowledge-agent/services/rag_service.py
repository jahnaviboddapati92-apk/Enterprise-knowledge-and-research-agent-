"""RAG service: embeddings, vector store and retrieval. (Placeholder - coming in a later step.)"""


class RAGService:
    """Will index document chunks and retrieve the most relevant ones for a question."""

    def index_document(self, filename: str, chunks: list[str]) -> None:
        raise NotImplementedError("Indexing is not implemented yet.")

    def retrieve(self, query: str, top_k: int = 4) -> list[dict]:
        raise NotImplementedError("Retrieval is not implemented yet.")

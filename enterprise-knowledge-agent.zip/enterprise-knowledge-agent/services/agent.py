"""Agent: planning, tool calling and Groq LLM calls. (Placeholder - coming in a later step.)"""


class KnowledgeAgent:
    """Will plan steps, call tools, and return structured answers."""

    def run(self, question: str) -> dict:
        raise NotImplementedError("The agent is not implemented yet.")

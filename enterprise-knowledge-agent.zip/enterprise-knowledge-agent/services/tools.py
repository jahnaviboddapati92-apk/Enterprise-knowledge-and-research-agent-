"""Tools the agent can call (e.g. document search, summarizer). (Placeholder - coming in a later step.)"""

# Later: a registry mapping tool names to functions and their JSON schemas.
TOOLS: dict = {}

"""Central configuration. All secrets/settings come from environment variables (.env)."""
import os
from pathlib import Path

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent

# Load variables from a local .env file (if present) into os.environ.
load_dotenv(BASE_DIR / ".env")


class Config:
    # --- Flask ---
    SECRET_KEY = os.getenv("SECRET_KEY", "dev-only-secret")
    DEBUG = os.getenv("FLASK_DEBUG", "0") == "1"
    PORT = int(os.getenv("PORT", "5000"))

    # --- Paths ---
    UPLOAD_FOLDER = BASE_DIR / "uploads"   # raw uploaded documents
    DATA_FOLDER = BASE_DIR / "data"        # future: vector store, memory files

    # --- Uploads ---
    ALLOWED_EXTENSIONS = {"pdf"}
    MAX_CONTENT_LENGTH = int(os.getenv("MAX_UPLOAD_MB", "25")) * 1024 * 1024

    # --- Groq (read now, used in a later step; never hard-code the key) ---
    _groq_key = os.getenv("GROQ_API_KEY", "")
    # Treat the .env.example placeholder as "not set".
    GROQ_API_KEY = "" if _groq_key.startswith("your-") else _groq_key
    GROQ_MODEL = os.getenv("GROQ_MODEL", "llama-3.3-70b-versatile")

"""Conversation memory / context management. (Placeholder - coming in a later step.)"""


class ConversationMemory:
    """Will store recent messages and build context for each agent call."""

    def add(self, role: str, content: str) -> None:
        raise NotImplementedError("Memory is not implemented yet.")

    def get_context(self) -> list[dict]:
        raise NotImplementedError("Memory is not implemented yet.")

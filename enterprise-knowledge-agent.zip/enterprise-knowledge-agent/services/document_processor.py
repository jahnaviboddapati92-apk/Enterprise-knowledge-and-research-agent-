"""Document processing: PDF text extraction and chunking. (Placeholder - coming in a later step.)"""


class DocumentProcessor:
    """Will extract text from PDFs and split it into chunks for indexing."""

    def extract_text(self, file_path: str) -> str:
        raise NotImplementedError("PDF extraction is not implemented yet.")

    def chunk_text(self, text: str) -> list[str]:
        raise NotImplementedError("Chunking is not implemented yet.")

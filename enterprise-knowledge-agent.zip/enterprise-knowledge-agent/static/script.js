// Front-end logic: upload PDFs, list documents, and send questions to the backend.
const fileInput = document.getElementById("file-input");
const dropzone = document.getElementById("dropzone");
const statusEl = document.getElementById("upload-status");
const docList = document.getElementById("doc-list");
const docEmpty = document.getElementById("doc-empty");
const messages = document.getElementById("messages");
const chatEmpty = document.getElementById("chat-empty");
const form = document.getElementById("chat-form");
const questionInput = document.getElementById("question");

function setStatus(text, isError = false) {
  statusEl.textContent = text;
  statusEl.classList.toggle("error", isError);
}

// Refresh the list of uploaded documents.
async function loadDocuments() {
  const res = await fetch("/documents");
  const { documents } = await res.json();
  docList.innerHTML = "";
  documents.forEach((name) => {
    const li = document.createElement("li");
    li.textContent = name;
    docList.appendChild(li);
  });
  docEmpty.hidden = documents.length > 0;
}

// Upload one file to the server.
async function uploadFile(file) {
  const data = new FormData();
  data.append("file", file);
  setStatus("Uploading…");
  try {
    const res = await fetch("/upload", { method: "POST", body: data });
    const body = await res.json();
    if (!res.ok) throw new Error(body.error || "Upload failed.");
    setStatus(body.message);
    loadDocuments();
  } catch (err) {
    setStatus(err.message, true);
  }
}

fileInput.addEventListener("change", () => fileInput.files[0] && uploadFile(fileInput.files[0]));
["dragover", "dragenter"].forEach((ev) =>
  dropzone.addEventListener(ev, (e) => { e.preventDefault(); dropzone.classList.add("drag"); }));
["dragleave", "drop"].forEach((ev) =>
  dropzone.addEventListener(ev, (e) => { e.preventDefault(); dropzone.classList.remove("drag"); }));
dropzone.addEventListener("drop", (e) => e.dataTransfer.files[0] && uploadFile(e.dataTransfer.files[0]));

// Add a chat bubble.
function addMessage(text, role) {
  chatEmpty.hidden = true;
  const div = document.createElement("div");
  div.className = `msg ${role}`;
  div.textContent = text;
  messages.appendChild(div);
  messages.scrollTop = messages.scrollHeight;
}

// Send a question to the backend.
form.addEventListener("submit", async (e) => {
  e.preventDefault();
  const question = questionInput.value.trim();
  if (!question) return;
  addMessage(question, "user");
  questionInput.value = "";
  try {
    const res = await fetch("/ask", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ question }),
    });
    const body = await res.json();
    addMessage(res.ok ? body.answer : body.error, "agent");
  } catch {
    addMessage("Could not reach the server.", "agent");
  }
});

loadDocuments();

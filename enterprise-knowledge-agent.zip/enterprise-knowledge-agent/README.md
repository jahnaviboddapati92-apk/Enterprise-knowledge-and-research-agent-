# Enterprise Knowledge & Research Agent

An Agentic AI application where users upload enterprise documents (PDFs) and ask questions about them.
The project is being built step by step.

## Current status: Step 1 - project scaffold

Working now: Flask web app, PDF upload to `uploads/`, chat UI with a placeholder reply, `.env` configuration.

Planned (not implemented yet): Groq LLM, RAG with a vector database, agent planning, tool calling,
memory/context management, structured responses.

## Project structure

```
enterprise-knowledge-agent/
├── app.py                  # Flask app and routes
├── config.py               # Settings loaded from .env
├── requirements.txt
├── .env.example            # Template for environment variables
├── uploads/                # Uploaded PDFs
├── data/                   # Future: vector store, memory
├── services/               # Placeholder modules for upcoming steps
│   ├── document_processor.py   # PDF extraction and chunking
│   ├── rag_service.py          # Embeddings and retrieval
│   ├── agent.py                # Planning, tool calling, Groq
│   ├── tools.py                # Tools the agent can call
│   └── memory.py               # Conversation memory
├── templates/index.html
└── static/ (style.css, script.js)
```

## How to run

Requires Python 3.10+.

```bash
cd enterprise-knowledge-agent

# 1. Create and activate a virtual environment
python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate

# 2. Install dependencies
pip install -r requirements.txt

# 3. Create your environment file
cp .env.example .env              # Windows: copy .env.example .env
# Edit .env: set SECRET_KEY (GROQ_API_KEY is not needed yet)

# 4. Start the app
python app.py
```

Open http://127.0.0.1:5000 in your browser. Check http://127.0.0.1:5000/health to confirm the server is running.

## Security notes

- API keys live only in `.env`, which is git-ignored. Commit `.env.example`, never `.env`.
